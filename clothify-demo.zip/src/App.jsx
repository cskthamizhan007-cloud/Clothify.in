import React, { useState, useEffect } from 'react';

const SAMPLE_PRODUCTS = [
  { id: 'tee-001', name: 'Classic White Tee', price: 499, tag: 'Men', img: 'https://images.unsplash.com/photo-1512436991641-6745cdb1723f?w=800&q=80', desc: 'Soft 100% cotton. Regular fit.' },
  { id: 'hood-002', name: 'Cozy Hoodie', price: 1299, tag: 'Unisex', img: 'https://images.unsplash.com/photo-1602810311201-2f3f0b3b7b9b?w=800&q=80', desc: 'Brushed fleece inside. Front pouch pocket.' },
  { id: 'dress-003', name: 'Summer Dress', price: 1599, tag: 'Women', img: 'https://images.unsplash.com/photo-1520975919109-1f51b0b5b4d2?w=800&q=80', desc: 'Lightweight, breathable fabric.' },
  { id: 'cap-004', name: 'Classic Cap', price: 349, tag: 'Accessories', img: 'https://images.unsplash.com/photo-1520975919109-1f51b0b5b4d2?w=800&q=80', desc: 'Adjustable strap.' },
];

function formatINR(n){ return `₹${n.toLocaleString('en-IN')}`; }

export default function App(){
  const [products] = useState(SAMPLE_PRODUCTS);
  const [cart, setCart] = useState([]);
  const [query, setQuery] = useState('');
  const [tagFilter, setTagFilter] = useState('All');
  const [checkoutMsg, setCheckoutMsg] = useState('');

  useEffect(()=>{ const s = localStorage.getItem('clothify_cart_v1'); if(s) setCart(JSON.parse(s)); }, []);
  useEffect(()=>{ localStorage.setItem('clothify_cart_v1', JSON.stringify(cart)); }, [cart]);

  const tags = ['All', ...Array.from(new Set(products.map(p=>p.tag)))];
  const filtered = products.filter(p=>{
    const matchesTag = tagFilter==='All' || p.tag===tagFilter;
    const q = query.trim().toLowerCase();
    const matchesQ = !q || p.name.toLowerCase().includes(q) || p.desc.toLowerCase().includes(q);
    return matchesTag && matchesQ;
  });

  const addToCart = (p)=> setCart(c=>{ const f = c.find(x=>x.id===p.id); if(f) return c.map(x=>x.id===p.id?{...x, qty:x.qty+1}:x); return [...c, {...p, qty:1}]; });
  const changeQty = (id,delta)=> setCart(c=> c.map(x=>x.id===id?{...x, qty:Math.max(0,x.qty+delta)}:x).filter(x=>x.qty>0));
  const resetCart = ()=> setCart([]);

  const subtotal = cart.reduce((s,it)=> s + it.price*it.qty, 0);
  const shipping = subtotal>1999 || subtotal===0 ? 0 : 99;
  const total = subtotal + shipping;

  async function startStripeCheckout(){
    if(cart.length===0){ setCheckoutMsg('Cart empty'); return; }
    // call backend endpoint to create Stripe session. See README for server code & env vars.
    try{
      const res = await fetch('/api/create-checkout-session', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ items: cart })
      });
      const data = await res.json();
      if(data.url) window.location = data.url;
      else setCheckoutMsg('Checkout creation failed: '+(data.message||'unknown'));
    }catch(err){ setCheckoutMsg('Network error creating checkout.'); }
  }

  function placeMailOrder(){
    if(cart.length===0){ setCheckoutMsg('Cart empty'); return; }
    const orderText = cart.map(it=>`${it.qty} x ${it.name} — ${formatINR(it.price)}`).join('\n');
    const body = encodeURIComponent(`New order (demo):\n\n${orderText}\n\nSubtotal: ${formatINR(subtotal)}\nShipping: ${formatINR(shipping)}\nTotal: ${formatINR(total)}`);
    window.location.href = `mailto:you@yourstore.com?subject=New Clothify Order&body=${body}`;
  }

  return (
    <div className="min-h-screen">
      <header className="bg-white shadow">
        <div className="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-orange-500 rounded-full flex items-center justify-center text-white font-bold">C</div>
            <div>
              <h1 className="text-xl font-semibold">Clothify</h1>
              <p className="text-xs text-gray-500">Clean. Comfortable. Confident.</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className="hidden sm:flex items-center gap-2 bg-gray-100 rounded-full px-3 py-1">
              <input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search products..." className="bg-transparent outline-none text-sm"/>
              <button onClick={()=>setQuery('')} className="text-xs text-gray-400">Clear</button>
            </div>
            <div className="flex items-center gap-2">
              <select value={tagFilter} onChange={e=>setTagFilter(e.target.value)} className="text-sm rounded border p-1">
                {tags.map(t=><option key={t} value={t}>{t}</option>)}
              </select>
              <button onClick={()=>document.getElementById('cartbox').scrollIntoView()} className="relative">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2 9m5-9v9m6-9v9m1-13h2" /></svg>
                {cart.length>0 && <span className="absolute -top-2 -right-2 bg-red-600 text-white rounded-full text-xs px-1">{cart.reduce((s,x)=>s+x.qty,0)}</span>}
              </button>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-4 py-8 grid grid-cols-1 md:grid-cols-4 gap-6">
        <section className="md:col-span-3">
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {filtered.map(p=>(
              <div key={p.id} className="bg-white rounded-2xl shadow-sm overflow-hidden">
                <div className="h-44 bg-gray-100 flex items-center justify-center overflow-hidden">
                  <img src={p.img} alt={p.name} className="object-cover w-full h-full"/>
                </div>
                <div className="p-4">
                  <h3 className="font-semibold">{p.name}</h3>
                  <p className="text-sm text-gray-500 mt-1">{p.desc}</p>
                  <div className="mt-3 flex items-center justify-between">
                    <div className="text-lg font-bold">{formatINR(p.price)}</div>
                    <div className="flex gap-2">
                      <button onClick={()=>addToCart(p)} className="text-sm px-3 py-1 rounded bg-orange-500 text-white">Add</button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </section>

        <aside id="cartbox" className="md:col-span-1">
          <div className="sticky top-6 bg-white p-4 rounded-2xl shadow-sm">
            <h4 className="font-semibold">Cart</h4>
            {cart.length===0 ? <p className="text-sm text-gray-500 mt-2">Your cart is empty.</p> : (
              <div className="space-y-3 mt-3">
                {cart.map(it=>(
                  <div key={it.id} className="flex items-center gap-3">
                    <img src={it.img} alt="" className="w-12 h-12 object-cover rounded"/>
                    <div className="flex-1">
                      <div className="text-sm font-medium">{it.name}</div>
                      <div className="text-xs text-gray-500">{formatINR(it.price)}</div>
                      <div className="flex items-center gap-2 mt-2">
                        <button onClick={()=>changeQty(it.id,-1)} className="px-2 py-1 rounded bg-gray-100">-</button>
                        <div className="text-sm">{it.qty}</div>
                        <button onClick={()=>changeQty(it.id,1)} className="px-2 py-1 rounded bg-gray-100">+</button>
                      </div>
                    </div>
                  </div>
                ))}
                <div className="border-t pt-3">
                  <div className="flex justify-between text-sm"><span>Subtotal</span><span>{formatINR(subtotal)}</span></div>
                  <div className="flex justify-between text-sm"><span>Shipping</span><span>{formatINR(shipping)}</span></div>
                  <div className="flex justify-between font-semibold mt-2"><span>Total</span><span>{formatINR(total)}</span></div>
                  <div className="mt-3 flex gap-2">
                    <button onClick={startStripeCheckout} className="flex-1 bg-indigo-600 text-white rounded py-2">Pay with Stripe</button>
                    <button onClick={placeMailOrder} className="px-3 py-2 bg-gray-100 rounded">Email order</button>
                  </div>
                  {checkoutMsg && <div className="text-xs text-gray-500 mt-2">{checkoutMsg}</div>}
                </div>
              </div>
            )}
            <hr className="my-3" />
            <div>
              <h5 className="text-sm font-medium">Contact</h5>
              <p className="text-xs text-gray-500 mt-1">Email: hello@clothify.com</p>
              <p className="text-xs text-gray-500">Phone: +91 90000 00000</p>
            </div>
          </div>
        </aside>
      </main>

      <footer className="bg-white border-t py-6">
        <div className="max-w-6xl mx-auto px-4 text-center text-sm text-gray-500">
          © {new Date().getFullYear()} Clothify — Demo
        </div>
      </footer>
    </div>
  );
}
