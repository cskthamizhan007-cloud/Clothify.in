// Example serverless function (Node.js) for creating Stripe Checkout Session.
// Deploy this as a serverless function (Vercel/Netlify) or an Express endpoint.
//
// Set environment variable: STRIPE_SECRET_KEY
//
import Stripe from 'stripe';
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ message: 'Method not allowed' });
  try {
    const { items } = req.body;
    const line_items = items.map(i => ({
      price_data: {
        currency: 'inr',
        product_data: { name: i.name },
        unit_amount: i.price * 100,
      },
      quantity: i.qty,
    }));
    const session = await stripe.checkout.sessions.create({
      payment_method_types: ['card'],
      line_items,
      mode: 'payment',
      success_url: process.env.SUCCESS_URL || 'https://your-site.com/success',
      cancel_url: process.env.CANCEL_URL || 'https://your-site.com/cancel',
    });
    res.json({ url: session.url });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
}
